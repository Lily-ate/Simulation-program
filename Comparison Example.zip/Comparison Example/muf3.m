function y=muf3(x1,x2,x3,a)
temp1=-(x1-3+a)^2/4;
temp2=-(x2-3+a)^2/4;
temp3=-(x3-3+a)^2/4;
y=exp(temp1)*exp(temp2)*exp(temp3);
end

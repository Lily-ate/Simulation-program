function y=muf1(x1,a)
temp=-(x1-3+a)^2/4;
y=exp(temp);
end

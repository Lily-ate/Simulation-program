clf;close all;
figure(1);
y0=0.6*sin(tout);
plot(tout,y0,'m--',tout,x(:,1),'b-',tout,x(:,4),'r-',tout,x(:,7),'g-',tout,x(:,10),'c-');
axis([0,20,-0.7,0.7]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$y_0$','$y_1$','$y_2$','$y_3$','$y_4$','Interpreter','latex');

figure(2);
subplot(2,2,1);
bar_kappa_11=2*exp(-tout)+1+0.1*sin(tout);
plot(tout,bar_kappa_11,tout,x(:,1),'b-',tout,x(:,73),'r',tout,-bar_kappa_11);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$\bar\kappa_{11}$','$\xi_{11}$','$\hat\xi_{11}$','$-\bar\kappa_{11}$','Interpreter','latex');
subplot(2,2,2);
bar_kappa_21=3*exp(-tout)+2.2+0.2*sin(tout);
plot(tout,bar_kappa_21,tout,x(:,4),'b-',tout,x(:,76),'r',tout,-bar_kappa_21);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$\bar\kappa_{21}$','$\xi_{21}$','$\hat\xi_{21}$','$-\bar\kappa_{21}$','Interpreter','latex');
subplot(2,2,3);
bar_kappa_31=3*exp(-tout)+2+0.2*sin(tout);
plot(tout,bar_kappa_31,tout,x(:,7),'b-',tout,x(:,79),'r',tout,-bar_kappa_31);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$\bar\kappa_{31}$','$\xi_{31}$','$\hat\xi_{31}$','$-\bar\kappa_{31}$','Interpreter','latex');
subplot(2,2,4);
bar_kappa_41=4*exp(-tout)+3.6+0.3*sin(tout);
plot(tout,bar_kappa_41,tout,x(:,10),'b-',tout,x(:,82),'r',tout,-bar_kappa_41);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$\bar\kappa_{41}$','$\xi_{41}$','$\hat\xi_{41}$','$-\bar\kappa_{41}$','Interpreter','latex');

figure(3);
plot(tout,x(:,1)-x(:,73),'r-',tout,x(:,4)-x(:,76),'b-',tout,x(:,7)-x(:,79),'g-',tout,x(:,10)-x(:,82),'c-');
set(gca,'XTick',0:2:20);
set(gca,'YTick',-0.02:0.01:0.02);
axis([0 20 -0.02 0.02])
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$\tilde{\xi}_{11}$','$\tilde{\xi}_{21}$','$\tilde{\xi}_{31}$','$\tilde{\xi}_{41}$','Interpreter','latex');

figure(4);
subplot(2,2,1);
bar_kappa_12=2*exp(-tout)+1.8+0.1*sin(tout);
plot(tout,bar_kappa_12,tout,x(:,2),'b-',tout,x(:,74),'r',tout,-bar_kappa_12);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$\bar\kappa_{12}$','$\xi_{12}$','$\hat\xi_{12}$','$-\bar\kappa_{12}$','Interpreter','latex');
subplot(2,2,2);
bar_kappa_22=2*exp(-tout)+1.8+0.1*sin(tout);
plot(tout,bar_kappa_22,tout,x(:,5),'b-',tout,x(:,77),'r',tout,-bar_kappa_22);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$\bar\kappa_{22}$','$\xi_{22}$','$\hat\xi_{22}$','$-\bar\kappa_{22}$','Interpreter','latex');
subplot(2,2,3);
bar_kappa_32=2*exp(-tout)+1.8+0.1*sin(tout);
plot(tout,bar_kappa_32,tout,x(:,8),'b-',tout,x(:,80),'r',tout,-bar_kappa_32);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$\bar\kappa_{32}$','$\xi_{32}$','$\hat\xi_{32}$','$-\bar\kappa_{32}$','Interpreter','latex');
subplot(2,2,4);
bar_kappa_42=2*exp(-tout)+1.8+0.1*sin(tout);
plot(tout,bar_kappa_42,tout,x(:,11),'b-',tout,x(:,83),'r',tout,-bar_kappa_42);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$\bar\kappa_{42}$','$\xi_{42}$','$\hat\xi_{42}$','$-\bar\kappa_{42}$','Interpreter','latex');

figure(5);
plot(tout,x(:,2)-x(:,74),'r-',tout,x(:,5)-x(:,77),'b-',tout,x(:,8)-x(:,80),'g-',tout,x(:,11)-x(:,83),'c-');
axis([0,20,-0.3,0.3]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$\tilde{\xi}_{12}$','$\tilde{\xi}_{22}$','$\tilde{\xi}_{32}$','$\tilde{\xi}_{42}$','Interpreter','latex');

figure(6);
subplot(2,2,1);
plot(tout,x(:,3),'b-',tout,x(:,75),'r');
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$\xi_{13}$','$\hat\xi_{13}$','Interpreter','latex');
subplot(2,2,2);
plot(tout,x(:,6),'b-',tout,x(:,78),'r');
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$\xi_{23}$','$\hat\xi_{23}$','Interpreter','latex');
subplot(2,2,3);
plot(tout,x(:,9),'b-',tout,x(:,81),'r');
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$\xi_{33}$','$\hat\xi_{33}$','Interpreter','latex');
subplot(2,2,4);
plot(tout,x(:,12),'b-',tout,x(:,84),'r');
axis([0,20,-1.2,3]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$\xi_{43}$','$\hat\xi_{43}$','Interpreter','latex');

figure(7);
plot(tout,x(:,3)-x(:,75),'r-',tout,x(:,6)-x(:,78),'b-',tout,x(:,9)-x(:,81),'g-',tout,x(:,12)-x(:,84),'c-');
axis([0,20,-0.5,0.5]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$\tilde{\xi}_{13}$','$\tilde{\xi}_{23}$','$\tilde{\xi}_{33}$','$\tilde{\xi}_{43}$','Interpreter','latex');

z_11=x(:,1)-y0;
z_21=2*x(:,4)-x(:,1)-x(:,7);
z_31=x(:,7)-x(:,1);
z_41=2*x(:,10)-x(:,7)-x(:,4);
k_11=bar_kappa_11;
k_21=2*bar_kappa_21-bar_kappa_11-bar_kappa_31;
k_31=bar_kappa_31-bar_kappa_11;
k_41=2*bar_kappa_41-bar_kappa_21-bar_kappa_31;
figure(8);
subplot(2,2,1);
plot(tout,k_11,'g-',tout,z_11,'b-',tout,-k_11,'r-');
axis([0,20,-3,3]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$k_{11}$','$z_{11}$','$-k_{11}$','Interpreter','latex');
subplot(2,2,2);
plot(tout,k_21,'g-',tout,z_21,'b-',tout,-k_21,'r-');
axis([0,20,-3,3]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$k_{21}$','$z_{21}$','$-k_{21}$','Interpreter','latex');
subplot(2,2,3);
plot(tout,k_31,'g-',tout,z_31,'b-',tout,-k_31,'r-');
axis([0,20,-2,2]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$k_{31}$','$z_{31}$','$-k_{31}$','Interpreter','latex');
subplot(2,2,4);
plot(tout,k_41,'g-',tout,z_41,'b-',tout,-k_41,'r-');
axis([0,20,-6,6]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$k_{41}$','$z_{41}$','$-k_{41}$','Interpreter','latex');

figure(9);
z_12=x(:,74)-x(:,85);
z_22=x(:,77)-x(:,86);
z_32=x(:,80)-x(:,87);
z_42=x(:,83)-x(:,88);
k_12=bar_kappa_12-max(x(:,85)-a(:,9))-max(a(:,9))-max(x(:,2)-x(:,74));
k_22=bar_kappa_22-max(x(:,86)-a(:,10))-max(a(:,10))-max(x(:,5)-x(:,77));
k_32=bar_kappa_32-max(x(:,87)-a(:,11))-max(a(:,11))-max(x(:,8)-x(:,80));
k_42=bar_kappa_42-max(x(:,88)-a(:,12))-max(a(:,12))-max(x(:,11)-x(:,83));
subplot(2,2,1);
plot(tout,k_12,'g-',tout,z_12,'b-',tout,-k_12,'r-');
axis([0,20,-3,3]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$k_{12}$','$z_{12}$','$-k_{12}$','Interpreter','latex');
subplot(2,2,2);
plot(tout,k_22,'g-',tout,z_22,'b-',tout,-k_22,'r-');
axis([0,20,-3,3]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$k_{22}$','$z_{22}$','$-k_{22}$','Interpreter','latex');
subplot(2,2,3);
plot(tout,k_32,'g-',tout,z_32,'b-',tout,-k_32,'r-');
axis([0,20,-3,3]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$k_{32}$','$z_{32}$','$-k_{32}$','Interpreter','latex');
subplot(2,2,4);
plot(tout,k_42,'g-',tout,z_42,'b-',tout,-k_42,'r-');
axis([0,20,-3,3]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$k_{42}$','$z_{42}$','$-k_{42}$','Interpreter','latex');

figure(10);
subplot(2,2,1);
z_13=x(:,75)-x(:,89)-x(:,93);
z_23=x(:,78)-x(:,90)-x(:,94);
z_33=x(:,81)-x(:,91)-x(:,95);
z_43=x(:,84)-x(:,92)-x(:,96);
plot(tout,z_13,'b-');
axis([0,20,-10,10]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$z_{13}$','Interpreter','latex');
subplot(2,2,2);
plot(tout,z_23,'b-');
axis([0,20,-10,10]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$z_{23}$','Interpreter','latex');
subplot(2,2,3);
plot(tout,z_33,'b-');
axis([0,20,-10,10]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$z_{33}$','Interpreter','latex');
subplot(2,2,4);
plot(tout,z_43,'b-');
axis([0,20,-10,10]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$z_{43}$','Interpreter','latex');

figure(11);
plot(tout,a(:,1),'r-',tout,a(:,5),'b--');
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$sat_1(\nu_1)$','$\nu_1$','Interpreter','latex');
axes('Position',[0.3,0.6,0.38,0.28]); 
plot(tout,a(:,1),'r',tout,a(:,5),'b--','LineWidth',1);
xlim([0,0.6]); 
ylim([-12,12]);

figure(12);
plot(tout,a(:,2),'r',tout,a(:,6),'b--');
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$sat_2(\nu_2)$','$\nu_2$','Interpreter','latex');
axes('Position',[0.3,0.6,0.38,0.28]); 
plot(tout,a(:,2),'r',tout,a(:,6),'b--','LineWidth',1);
xlim([0,0.6]); 
ylim([-12,12]);

figure(13);
plot(tout,a(:,3),'r',tout,a(:,7),'b--');
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$sat_3(\nu_3)$','$\nu_3$','Interpreter','latex');
axes('Position',[0.3,0.6,0.38,0.28]); 
plot(tout,a(:,3),'r',tout,a(:,7),'b--','LineWidth',1);
xlim([0,0.6]); 
ylim([-12,12]);

figure(14);
plot(tout,a(:,4),'r',tout,a(:,8),'b--');
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$sat_4(\nu_4)$','$\nu_4$','Interpreter','latex');
axes('Position',[0.3,0.6,0.38,0.28]); 
plot(tout,a(:,4),'r',tout,a(:,8),'b--','LineWidth',1);
xlim([0,0.6]); 
ylim([-12,12]);

figure(15);
subplot(2,2,1);
clear z;
c=a(:,5);
for i=1:length(c)-1
    if c(i+1)==c(i)
        z(i)=0;
    else
        z(i)=abs(c(i));
    end
end
real=find(z~=0);
z(z==0)=[];
A=tout(real);
d1=size(A);
B=diff(A);
stem(A,[0;B],'b-');
xlabel('time(sec)');
legend('$t^1_{k+1}-t^1_k$','interpreter','latex');

subplot(2,2,2);
clear z;
c=a(:,6);
for i=1:length(c)-1
    if c(i+1)==c(i)
        z(i)=0;
    else
        z(i)=abs(c(i));
    end
end
real=find(z~=0);
z(z==0)=[];
A=tout(real);
d2=size(A);
B=diff(A);
stem(A,[0;B],'b-');
xlabel('time(sec)');
legend('$t^2_{k+1}-t^2_k$','interpreter','latex');

subplot(2,2,3);
clear z;
c=a(:,7);
for i=1:length(c)-1
    if c(i+1)==c(i)
        z(i)=0;
    else
        z(i)=abs(c(i));
    end
end
real=find(z~=0);
z(z==0)=[];
A=tout(real);
d3=size(A);
B=diff(A);
stem(A,[0;B],'b-');
xlabel('time(sec)');
legend('$t^3_{k+1}-t^3_k$','interpreter','latex');

subplot(2,2,4);
clear z;
c=a(:,8);
for i=1:length(c)-1
    if c(i+1)==c(i)
        z(i)=0;
    else
        z(i)=abs(c(i));
    end
end
real=find(z~=0);
z(z==0)=[];
A=tout(real);
d4=size(A);
B=diff(A);
stem(A,[0;B],'b-');
xlabel('time(sec)');
legend('$t^4_{k+1}-t^4_k$','interpreter','latex');

figure(16);
plot(tout,x(:,1)-y0,'b-',tout,x(:,4)-y0,'r-',tout,x(:,7)-y0,'g-',tout,x(:,10)-y0,'c-');
axis([0,20,-0.11,0.1]);
xlabel('time(sec)');
set(findall(gcf,'type','line'),'linewidth',0.8);
legend('$y_1-y_0$','$y_2-y_0$','$y_3-y_0$','$y_4-y_0$','Interpreter','latex');

function [sys,x0,str,ts] =Multiagent_system(t,x,u,flag)
switch flag
  case 0
    [sys,x0,str,ts]=mdlInitializeSizes;
  case 1
    sys=mdlDerivatives(t,x,u);
  case 2
    sys=mdlUpdate(t,x,u);
  case 3
    sys=mdlOutputs(t,x,u);
  case 4
    sys=mdlGetTimeOfNextVarHit(t,x,u);
  case 9
    sys=mdlTerminate(t,x,u);
  otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end

function [sys,x0,str,ts]=mdlInitializeSizes
global u_1 u_2 u_3 u_4 v_1 v_2 v_3 v_4 g_1 g_2 g_3 g_4
v_1=0;v_2=0;v_3=0;v_4=0;u_1=0;u_2=0;u_3=0;u_4=0;g_1=0;g_2=0;g_3=0;g_4=0;
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 125;
sizes.NumInputs      = 105;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   
sys = simsizes(sizes);
x0=[];
str = [];
ts  = [0 0];

function sys=mdlUpdate(t,~,u)
sys = [];

function sys=mdlOutputs(t,x,u)
global u_1 u_2 u_3 u_4 v_1 v_2 v_3 v_4 g_1 g_2 g_3 g_4
y0=0.6*sin(t);
kappa_1=[10;10;10;10];kappa_2=[15;15;15;15];kappa_3=[20;20;20;20];
gamma_1=[0.06;0.06;0.06;0.06];gamma_2=[0.06;0.06;0.06;0.06];gamma_3=[0.06;0.06;0.06;0.06];
sigma_1=[10;10;10;10];sigma_2=[10;10;10;10];sigma_3=[10;10;10;10];
zeta=0.05;
c_1=[5;5;5;5];c_2=[5;5;5;5];c_3=[5;5;5;5];
bar_kappa_1=[2*exp(-t)+1+0.1*sin(t);3*exp(-t)+2.2+0.2*sin(t);3*exp(-t)+2+0.2*sin(t);4*exp(-t)+3.6+0.3*sin(t)];
bar_kappa_2=[2*exp(-t)+1.8+0.1*sin(t);2*exp(-t)+1.8+0.1*sin(t);2*exp(-t)+1.8+0.1*sin(t);2*exp(-t)+1.8+0.1*sin(t)];
p=[0.1;0.1;0.1;0.1];epsilon=[1;1;1;1];rho=[1;1;1;1];
m=[0.5;0.7;0.5;0.7];
bar_M=[9;9;9;9];underline_M=[-9;-9;-9;-9];

xi_11=u(1);xi_12=u(2);xi_13=u(3);
xi_21=u(4);xi_22=u(5);xi_23=u(6);
xi_31=u(7);xi_32=u(8);xi_33=u(9);
xi_41=u(10);xi_42=u(11);xi_43=u(12);
vartheta_11=[u(13);u(14);u(15);u(16);u(17)];vartheta_12=[u(18);u(19);u(20);u(21);u(22)];vartheta_13=[u(23);u(24);u(25);u(26);u(27)];
vartheta_21=[u(28);u(29);u(30);u(31);u(32)];vartheta_22=[u(33);u(34);u(35);u(36);u(37)];vartheta_23=[u(38);u(39);u(40);u(41);u(42)];
vartheta_31=[u(43);u(44);u(45);u(46);u(47)];vartheta_32=[u(48);u(49);u(50);u(51);u(52)];vartheta_33=[u(53);u(54);u(55);u(56);u(57)];
vartheta_41=[u(58);u(59);u(60);u(61);u(62)];vartheta_42=[u(63);u(64);u(65);u(66);u(67)];vartheta_43=[u(68);u(69);u(70);u(71);u(72)];
hat_xi_11=u(73);hat_xi_12=u(74);hat_xi_13=u(75);
hat_xi_21=u(76);hat_xi_22=u(77);hat_xi_23=u(78);
hat_xi_31=u(79);hat_xi_32=u(80);hat_xi_33=u(81);
hat_xi_41=u(82);hat_xi_42=u(83);hat_xi_43=u(84);
bar_chi_12=u(85);bar_chi_22=u(86);bar_chi_32=u(87);bar_chi_42=u(88);
bar_chi_13=u(89);bar_chi_23=u(90);bar_chi_33=u(91);bar_chi_43=u(92);
tilde_h_1=u(93);tilde_h_2=u(94);tilde_h_3=u(95);tilde_h_4=u(96);

D_k_11=u(97);D_k_21=u(98);D_k_31=u(99);D_k_41=u(100);
D_k_12=u(101);D_k_22=u(102);D_k_32=u(103);D_k_42=u(104);
D_y0=u(105);

Fuzzy_11=[muf1(xi_11,1);muf1(xi_11,2);muf1(xi_11,3);muf1(xi_11,4);muf1(xi_11,5)];
Fuzzy_12=[muf2(hat_xi_11,hat_xi_12,1);muf2(hat_xi_11,hat_xi_12,2);muf2(hat_xi_11,hat_xi_12,3);muf2(hat_xi_11,hat_xi_12,4);muf2(hat_xi_11,hat_xi_12,5)];
Fuzzy_13=[muf3(hat_xi_11,hat_xi_12,hat_xi_13,1);muf3(hat_xi_11,hat_xi_12,hat_xi_13,2);muf3(hat_xi_11,hat_xi_12,hat_xi_13,3);muf3(hat_xi_11,hat_xi_12,hat_xi_13,4);muf3(hat_xi_11,hat_xi_12,hat_xi_13,5)];
psi_11=Fuzzy_11./sum(Fuzzy_11);
psi_12=Fuzzy_12./sum(Fuzzy_12);
psi_13=Fuzzy_13./sum(Fuzzy_13);

Fuzzy_21=[muf1(xi_21,1);muf1(xi_21,2);muf1(xi_21,3);muf1(xi_21,4);muf1(xi_21,5)];
Fuzzy_22=[muf2(hat_xi_21,hat_xi_22,1);muf2(hat_xi_21,hat_xi_22,2);muf2(hat_xi_21,hat_xi_22,3);muf2(hat_xi_21,hat_xi_22,4);muf2(hat_xi_21,hat_xi_22,5)];
Fuzzy_23=[muf3(hat_xi_21,hat_xi_22,hat_xi_23,1);muf3(hat_xi_21,hat_xi_22,hat_xi_23,2);muf3(hat_xi_21,hat_xi_22,hat_xi_23,3);muf3(hat_xi_21,hat_xi_22,hat_xi_23,4);muf3(hat_xi_21,hat_xi_22,hat_xi_23,5)];
psi_21=Fuzzy_21./sum(Fuzzy_21);
psi_22=Fuzzy_22./sum(Fuzzy_22);
psi_23=Fuzzy_23./sum(Fuzzy_23);

Fuzzy_31=[muf1(xi_31,1);muf1(xi_31,2);muf1(xi_31,3);muf1(xi_31,4);muf1(xi_31,5)];
Fuzzy_32=[muf2(hat_xi_31,hat_xi_32,1);muf2(hat_xi_31,hat_xi_32,2);muf2(hat_xi_31,hat_xi_32,3);muf2(hat_xi_31,hat_xi_32,4);muf2(hat_xi_31,hat_xi_32,5)];
Fuzzy_33=[muf3(hat_xi_31,hat_xi_32,hat_xi_33,1);muf3(hat_xi_31,hat_xi_32,hat_xi_33,2);muf3(hat_xi_31,hat_xi_32,hat_xi_33,3);muf3(hat_xi_31,hat_xi_32,hat_xi_33,4);muf3(hat_xi_31,hat_xi_32,hat_xi_33,5)];
psi_31=Fuzzy_31./sum(Fuzzy_31);
psi_32=Fuzzy_32./sum(Fuzzy_32);
psi_33=Fuzzy_33./sum(Fuzzy_33);

Fuzzy_41=[muf1(xi_41,1);muf1(xi_41,2);muf1(xi_41,3);muf1(xi_41,4);muf1(xi_41,5)];
Fuzzy_42=[muf2(hat_xi_41,hat_xi_42,1);muf2(hat_xi_41,hat_xi_42,2);muf2(hat_xi_41,hat_xi_42,3);muf2(hat_xi_41,hat_xi_42,4);muf2(hat_xi_41,hat_xi_42,5)];
Fuzzy_43=[muf3(hat_xi_41,hat_xi_42,hat_xi_43,1);muf3(hat_xi_41,hat_xi_42,hat_xi_43,2);muf3(hat_xi_41,hat_xi_42,hat_xi_43,3);muf3(hat_xi_41,hat_xi_42,hat_xi_43,4);muf3(hat_xi_41,hat_xi_42,hat_xi_43,5)];
psi_41=Fuzzy_41./sum(Fuzzy_41);
psi_42=Fuzzy_42./sum(Fuzzy_42);
psi_43=Fuzzy_43./sum(Fuzzy_43);

L=[0 0 0 0;-1 2 -1 0;-1 0 1 0;0 -1 -1 2];B=[1 0 0 0;0 0 0 0;0 0 0 0;0 0 0 0];H=L+B;
k_11=bar_kappa_1(1);k_21=2*bar_kappa_1(2)-bar_kappa_1(1)-bar_kappa_1(3);k_31=bar_kappa_1(3)-bar_kappa_1(1);k_41=2*bar_kappa_1(4)-bar_kappa_1(3)-bar_kappa_1(2);
z_1=H*[xi_11-y0;xi_21-y0;xi_31-y0;xi_41-y0];
alpha_11=-c_1(1)*z_1(1)-4*z_1(1)/(k_11^2-z_1(1)^2)+D_y0+z_1(1)*D_k_11/(2*k_11*k_11)-vartheta_11'*psi_11;
alpha_21=1/2*(-c_1(2)*z_1(2)-16*z_1(2)/(k_21^2-z_1(2)^2)+hat_xi_12+vartheta_11'*psi_11+hat_xi_32+vartheta_31'*psi_31+z_1(2)*D_k_21/(2*k_21*k_21))-vartheta_21'*psi_21;
alpha_31=-c_1(3)*z_1(3)-4*z_1(3)/(k_31^2-z_1(3)^2)+hat_xi_12+vartheta_11'*psi_11+z_1(3)*D_k_31/(2*k_31*k_31)-vartheta_31'*psi_31;
alpha_41=1/2*(-c_1(4)*z_1(4)-16*z_1(4)/(k_41^2-z_1(4)^2)+hat_xi_22+vartheta_21'*psi_21+hat_xi_32+vartheta_31'*psi_31+z_1(4)*D_k_41/(2*k_41*k_41))-vartheta_41'*psi_41;

D_bar_chi_12=(1/zeta)*alpha_11-(1/zeta)*bar_chi_12;
D_bar_chi_22=(1/zeta)*alpha_21-(1/zeta)*bar_chi_22;
D_bar_chi_32=(1/zeta)*alpha_31-(1/zeta)*bar_chi_32;
D_bar_chi_42=(1/zeta)*alpha_41-(1/zeta)*bar_chi_42;

z_2=[hat_xi_12-bar_chi_12;hat_xi_22-bar_chi_22;hat_xi_32-bar_chi_32;hat_xi_42-bar_chi_42];
k_12=bar_kappa_2(1)-max(bar_chi_12-alpha_11)-max(alpha_11)-max(xi_12-hat_xi_12);
k_22=bar_kappa_2(2)-max(bar_chi_22-alpha_21)-max(alpha_21)-max(xi_22-hat_xi_22);
k_32=bar_kappa_2(3)-max(bar_chi_32-alpha_31)-max(alpha_31)-max(xi_32-hat_xi_32);
k_42=bar_kappa_2(4)-max(bar_chi_42-alpha_41)-max(alpha_21)-max(xi_42-hat_xi_42);
alpha_12=-c_2(1)*z_2(1)-0.5*z_2(1)*(k_12^2-z_2(1)^2)-1.5*z_2(1)/(k_12^2-z_2(1)^2)-vartheta_12'*psi_12-kappa_2(1)*(xi_11-hat_xi_11)+D_bar_chi_12+z_2(1)*D_k_12/(2*k_12*k_12);
alpha_22=-c_2(2)*z_2(2)-0.5*z_2(2)*(k_22^2-z_2(2)^2)-1.5*z_2(2)/(k_22^2-z_2(2)^2)-vartheta_22'*psi_22-kappa_2(2)*(xi_21-hat_xi_21)+D_bar_chi_22+z_2(2)*D_k_22/(2*k_22*k_22);
alpha_32=-c_2(3)*z_2(3)-0.5*z_2(3)*(k_32^2-z_2(3)^2)-1.5*z_2(3)/(k_32^2-z_2(3)^2)-vartheta_32'*psi_32-kappa_2(3)*(xi_31-hat_xi_31)+D_bar_chi_32+z_2(3)*D_k_32/(2*k_32*k_32);
alpha_42=-c_2(4)*z_2(4)-0.5*z_2(4)*(k_42^2-z_2(4)^2)-1.5*z_2(4)/(k_42^2-z_2(4)^2)-vartheta_42'*psi_42-kappa_2(4)*(xi_41-hat_xi_41)+D_bar_chi_42+z_2(4)*D_k_42/(2*k_42*k_42);

D_bar_chi_13=(1/zeta)*alpha_12-(1/zeta)*bar_chi_13;
D_bar_chi_23=(1/zeta)*alpha_22-(1/zeta)*bar_chi_23;
D_bar_chi_33=(1/zeta)*alpha_32-(1/zeta)*bar_chi_33;
D_bar_chi_43=(1/zeta)*alpha_42-(1/zeta)*bar_chi_43;

z_3=[hat_xi_13-bar_chi_13-tilde_h_1;hat_xi_23-bar_chi_23-tilde_h_2;hat_xi_33-bar_chi_33-tilde_h_3;hat_xi_43-bar_chi_43-tilde_h_4];
alpha_13=c_3(1)*z_3(1)+tilde_h_1+z_3(1)+vartheta_13'*psi_13+kappa_3(1)*(xi_11-hat_xi_11)-D_bar_chi_13;
alpha_23=c_3(2)*z_3(2)+tilde_h_2+z_3(2)+vartheta_23'*psi_23+kappa_3(2)*(xi_21-hat_xi_21)-D_bar_chi_23;
alpha_33=c_3(3)*z_3(3)+tilde_h_3+z_3(3)+vartheta_33'*psi_33+kappa_3(3)*(xi_31-hat_xi_31)-D_bar_chi_33;
alpha_43=c_3(4)*z_3(4)+tilde_h_4+z_3(4)+vartheta_43'*psi_43+kappa_3(4)*(xi_41-hat_xi_41)-D_bar_chi_43;

%ETC1
tau_1=-(1+p(1))*(alpha_13*tanh((alpha_13*z_3(1))/epsilon(1))+rho(1)*tanh((z_3(1)*rho(1))/epsilon(1)));
if abs(tau_1-v_1)>=p(1)*abs(v_1)+m(1)
    v_1=tau_1;
end
%saturation1
if v_1>=0
    g_1=bar_M(1)*tanh(v_1/bar_M(1));
else 
    g_1=underline_M(1)*tanh(v_1/underline_M(1));
end

if (underline_M(1)<v_1)&&(v_1<bar_M(1))
    u_1=v_1;
elseif v_1>=bar_M(1)
    u_1=bar_M(1);
else
    u_1=underline_M(1);
end

%ETC2
tau_2=-(1+p(2))*(alpha_23*tanh((alpha_23*z_3(2))/epsilon(2))+rho(2)*tanh((z_3(2)*rho(2))/epsilon(2)));
if abs(tau_2-v_2)>=p(2)*abs(v_2)+m(2)
    v_2=tau_2;
end
%saturation2
if v_2>=0
    g_2=bar_M(2)*tanh(v_2/bar_M(2));
else 
    g_2=underline_M(2)*tanh(v_2/underline_M(2));
end

if (underline_M(2)<v_2)&&(v_2<bar_M(2))
    u_2=v_2;
elseif v_2>=bar_M(2)
    u_2=bar_M(2);
else
    u_2=underline_M(2);
end

%ETC3
tau_3=-(1+p(3))*(alpha_33*tanh((alpha_33*z_3(3))/epsilon(3))+rho(3)*tanh((z_3(3)*rho(3))/epsilon(3)));
if abs(tau_3-v_3)>=p(3)*abs(v_3)+m(3)
    v_3=tau_3;
end
%saturation3
if v_3>=0
    g_3=bar_M(3)*tanh(v_3/bar_M(3));
else 
    g_3=underline_M(3)*tanh(v_3/underline_M(3));
end

if (underline_M(3)<v_3)&&(v_3<bar_M(3))
    u_3=v_3;
elseif v_3>=bar_M(3)
    u_3=bar_M(3);
else
    u_3=underline_M(3);
end

%ETC4
tau_4=-(1+p(4))*(alpha_43*tanh((alpha_43*z_3(4))/epsilon(4))+rho(4)*tanh((z_3(4)*rho(4))/epsilon(4)));
if abs(tau_4-v_4)>=p(4)*abs(v_4)+m(4)
    v_4=tau_4;
end
%saturation4
if v_4>=0
    g_4=bar_M(4)*tanh(v_4/bar_M(4));
else 
    g_4=underline_M(4)*tanh(v_4/underline_M(4));
end

if (underline_M(4)<v_4)&&(v_4<bar_M(4))
    u_4=v_4;
elseif v_4>=bar_M(4)
    u_4=bar_M(4);
else
    u_4=underline_M(4);
end

%main system
MS=[xi_12-0.05*xi_11^2*cos(xi_11)+0.02*sin(t)
    xi_13+0.03*(xi_12-0.6*xi_11^2)/(1+0.1*xi_11^3)+0.03*cos(t)
    u_1-0.06*exp(-xi_11^2)*sin(3*xi_12*xi_13)+0.05*cos(t)
    xi_22-0.05*xi_21^2*cos(xi_21)+0.02*sin(t)
    xi_23+0.03*(xi_22-0.6*xi_21^2)/(1+0.1*xi_21^3)+0.03*cos(t)
    u_2-0.06*exp(-xi_21^2)*sin(3*xi_22*xi_23)+0.05*cos(t)
    xi_32-0.05*xi_31^2*cos(xi_31)+0.02*sin(t)
    xi_33+0.03*(xi_32-0.6*xi_31^2)/(1+0.1*xi_31^3)+0.03*cos(t)
    u_3-0.06*exp(-xi_31^2)*sin(3*xi_32*xi_33)+0.05*cos(t)
    xi_42-0.05*xi_41^2*cos(xi_41)+0.02*sin(t)
    xi_43+0.03*(xi_42-0.6*xi_41^2)/(1+0.1*xi_41^3)+0.03*cos(t)
    u_4-0.06*exp(-xi_41^2)*sin(3*xi_42*xi_43)+0.05*cos(t)
    zeros(113,1)];
%adaptive law
D_vartheta_11=gamma_1(1)*z_1(1)*psi_11/(k_11^2-z_1(1)^2)-sigma_1(1)*vartheta_11;
D_vartheta_12=gamma_2(1)*z_2(1)*psi_12/(k_12^2-z_2(1)^2)-sigma_2(1)*vartheta_12;
D_vartheta_13=gamma_3(1)*z_3(1)*psi_13-sigma_3(1)*vartheta_13;
D_vartheta_21=2*gamma_1(2)*z_1(2)*psi_21/(k_21^2-z_1(2)^2)-sigma_1(2)*vartheta_21;
D_vartheta_22=gamma_2(2)*z_2(2)*psi_22/(k_22^2-z_2(2)^2)-sigma_2(2)*vartheta_22;
D_vartheta_23=gamma_3(2)*z_3(2)*psi_23-sigma_3(2)*vartheta_23;
D_vartheta_31=gamma_1(3)*z_1(3)*psi_31/(k_31^2-z_1(3)^2)-sigma_1(3)*vartheta_31;
D_vartheta_32=gamma_2(3)*z_2(3)*psi_32/(k_32^2-z_2(3)^2)-sigma_2(3)*vartheta_32;
D_vartheta_33=gamma_3(3)*z_3(3)*psi_33-sigma_3(3)*vartheta_33;
D_vartheta_41=2*gamma_1(4)*z_1(4)*psi_41/(k_41^2-z_1(4)^2)-sigma_1(4)*vartheta_41;
D_vartheta_42=gamma_2(4)*z_2(4)*psi_42/(k_42^2-z_2(4)^2)-sigma_2(4)*vartheta_42;
D_vartheta_43=gamma_3(4)*z_3(4)*psi_43-sigma_3(4)*vartheta_43;
D_vartheta=[zeros(12,1) 
            D_vartheta_11 
            D_vartheta_12 
            D_vartheta_13 
            D_vartheta_21 
            D_vartheta_22 
            D_vartheta_23 
            D_vartheta_31 
            D_vartheta_32 
            D_vartheta_33 
            D_vartheta_41 
            D_vartheta_42 
            D_vartheta_43 
        zeros(53,1)];
%observer
OB=[zeros(72,1)
    hat_xi_12+vartheta_11'*psi_11+kappa_1(1)*(xi_11-hat_xi_11)
    hat_xi_13+vartheta_12'*psi_12+kappa_2(1)*(xi_11-hat_xi_11)
    g_1+vartheta_13'*psi_13+kappa_3(1)*(xi_11-hat_xi_11)
    hat_xi_22+vartheta_21'*psi_21+kappa_1(2)*(xi_21-hat_xi_21)
    hat_xi_23+vartheta_22'*psi_22+kappa_2(2)*(xi_21-hat_xi_21)
    g_2+vartheta_23'*psi_23+kappa_3(2)*(xi_21-hat_xi_21)
    hat_xi_32+vartheta_31'*psi_31+kappa_1(3)*(xi_31-hat_xi_31)
    hat_xi_33+vartheta_32'*psi_32+kappa_2(3)*(xi_31-hat_xi_31)
    g_3+vartheta_33'*psi_33+kappa_3(3)*(xi_31-hat_xi_31)
    hat_xi_42+vartheta_41'*psi_41+kappa_1(4)*(xi_41-hat_xi_41)
    hat_xi_43+vartheta_42'*psi_42+kappa_2(4)*(xi_41-hat_xi_41)
    g_4+vartheta_43'*psi_43+kappa_3(4)*(xi_41-hat_xi_41)
    zeros(41,1)];
% fractional-order filter
D_bar_chi=[zeros(1,84) D_bar_chi_12 D_bar_chi_22 D_bar_chi_32 D_bar_chi_42 D_bar_chi_13 D_bar_chi_23 D_bar_chi_33 D_bar_chi_43 zeros(1,33)]';

H=[zeros(1,92) -tilde_h_1+g_1-v_1 -tilde_h_2+g_2-v_2 -tilde_h_3+g_3-v_3 -tilde_h_4+g_4-v_4 zeros(1,29)]';

K=[zeros(1,96) k_11*k_11 k_21*k_21 k_31*k_31 k_41*k_41 k_12*k_12 k_22*k_22 k_32*k_32 k_42*k_42 y0 zeros(1,20)]';

Alpha=[zeros(105,1)
       u_1
       u_2
       u_3
       u_4
       v_1
       v_2
       v_3
       v_4
       alpha_11
       alpha_21
       alpha_31
       alpha_41
       alpha_12
       alpha_22
       alpha_32
       alpha_42
       alpha_13
       alpha_23
       alpha_33
       alpha_43];
sys=MS+D_vartheta+OB+D_bar_chi+H+K+Alpha;

function sys=mdlGetTimeOfNextVarHit(t,x,u)
sampleTime=1;    
sys=t+sampleTime;

function sys=mdlTerminate(t,x,u)
sys=[];
